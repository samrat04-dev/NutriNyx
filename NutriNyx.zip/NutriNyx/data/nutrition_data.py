nutrition = {

    "apple": {
        "calories": 95,
        "protein": 0.5,
        "carbs": 25,
        "fat": 0.3
    },

    "banana": {
        "calories": 105,
        "protein": 1.3,
        "carbs": 27,
        "fat": 0.4
    },

    "rice": {
        "calories": 206,
        "protein": 4.3,
        "carbs": 45,
        "fat": 0.4
    },

    "paneer": {
        "calories": 265,
        "protein": 18,
        "carbs": 6,
        "fat": 20
    },

    "egg": {
        "calories": 78,
        "protein": 6,
        "carbs": 0.6,
        "fat": 5
    },

    "chicken": {
        "calories": 165,
        "protein": 31,
        "carbs": 0,
        "fat": 3.6
    }
}