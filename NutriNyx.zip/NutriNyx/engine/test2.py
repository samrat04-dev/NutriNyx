import pandas as pd
from pathlib import Path


# ==========================================
# PROJECT PATHS
# ==========================================

BASE_DIR = Path(__file__).resolve().parent.parent

input_file = BASE_DIR / "data" / "TestIndianWhole_cleaned.csv"
output_file = BASE_DIR / "data" / "TestIndianWhole_final.csv"


# ==========================================
# LOAD CSV
# ==========================================

print("Loading dataset...")

df = pd.read_csv(input_file)

print(f"Original rows: {len(df)}")


# ==========================================
# REMOVE DUPLICATE FOOD NAMES
# ==========================================

# Remove rows where Food_Name is duplicated.
# keep="first" keeps the first occurrence.
df = df.drop_duplicates(
    subset=["Food_Name"],
    keep="first"
)


# ==========================================
# CLEAN FOOD NAMES
# ==========================================

df["Food_Name"] = (
    df["Food_Name"]
    .astype(str)
    .str.strip()
)


# Remove duplicates again after cleaning spaces/casing
df = df.drop_duplicates(
    subset=["Food_Name"],
    keep="first"
)


# ==========================================
# SAVE CLEAN DATASET
# ==========================================

df.to_csv(
    output_file,
    index=False
)


# ==========================================
# RESULTS
# ==========================================

print("\n========== CLEANING COMPLETE ==========")

print(f"Original rows : {pd.read_csv(input_file).shape[0]}")
print(f"Final rows    : {len(df)}")
print(f"Duplicates removed : {pd.read_csv(input_file).shape[0] - len(df)}")

print("\nSaved to:")
print(output_file)