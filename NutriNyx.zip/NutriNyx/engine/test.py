from ml_model import predict_goal


# Example nutrition values
nutrition = {
    "Calories": 350,
    "Protein": 20,
    "Carbs": 45,
    "Fat": 10,
    "Fiber": 8,
    "Sugar": 10,
    "Sodium": 500
}


for goal in [
    "Weight Loss",
    "Muscle Gain",
    "Weight Gain",
    "Healthy Lifestyle"
]:

    result = predict_goal(nutrition, goal)

    print("\nGoal:", goal)
    print("Prediction:", result["prediction"])
    print("Confidence:", f"{result['confidence']:.2f}%")